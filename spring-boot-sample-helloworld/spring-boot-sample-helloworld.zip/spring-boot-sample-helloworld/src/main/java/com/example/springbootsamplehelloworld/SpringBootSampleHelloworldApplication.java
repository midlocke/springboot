package com.example.springbootsamplehelloworld;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSampleHelloworldApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSampleHelloworldApplication.class, args);
	}
}
